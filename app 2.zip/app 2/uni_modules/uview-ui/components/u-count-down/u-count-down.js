(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "uni_modules/uview-ui/components/u-count-down/u-count-down" ], {
    "03a9": function a9(i, t, e) {
        "use strict";
        var n = e("bf37"), a = e.n(n);
        a.a;
    },
    2420: function _(i, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return n;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var n = function n() {
            var i = this.$createElement;
            this._self._c;
        }, a = [];
    },
    "409d": function d(i, t, e) {
        "use strict";
        (function(i) {
            var n = e("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(e("ca04")), u = e("e864"), r = {
                name: "u-count-down",
                mixins: [ i.$u.mpMixin, i.$u.mixin, a.default ],
                data: function data() {
                    return {
                        timer: null,
                        timeData: (0, u.parseTimeData)(0),
                        formattedTime: "0",
                        runing: !1,
                        endTime: 0,
                        remainTime: 0
                    };
                },
                watch: {
                    time: function time(i) {
                        this.reset();
                    }
                },
                mounted: function mounted() {
                    this.init();
                },
                methods: {
                    init: function init() {
                        this.reset();
                    },
                    start: function start() {
                        this.runing || (this.runing = !0, this.endTime = Date.now() + this.remainTime, this.toTick());
                    },
                    toTick: function toTick() {
                        this.millisecond ? this.microTick() : this.macroTick();
                    },
                    macroTick: function macroTick() {
                        var i = this;
                        this.clearTimeout(), this.timer = setTimeout(function() {
                            var t = i.getRemainTime();
                            (0, u.isSameSecond)(t, i.remainTime) && 0 !== t || i.setRemainTime(t), 0 !== i.remainTime && i.macroTick();
                        }, 30);
                    },
                    microTick: function microTick() {
                        var i = this;
                        this.clearTimeout(), this.timer = setTimeout(function() {
                            i.setRemainTime(i.getRemainTime()), 0 !== i.remainTime && i.microTick();
                        }, 50);
                    },
                    getRemainTime: function getRemainTime() {
                        return Math.max(this.endTime - Date.now(), 0);
                    },
                    setRemainTime: function setRemainTime(i) {
                        this.remainTime = i;
                        var t = (0, u.parseTimeData)(i);
                        this.$emit("change", t), this.formattedTime = (0, u.parseFormat)(this.format, t), 
                        i <= 0 && (this.pause(), this.$emit("finish"));
                    },
                    reset: function reset() {
                        this.pause(), this.remainTime = this.time, this.setRemainTime(this.remainTime), 
                        this.autoStart && this.start();
                    },
                    pause: function pause() {
                        this.runing = !1, this.clearTimeout();
                    },
                    clearTimeout: function(i) {
                        function t() {
                            return i.apply(this, arguments);
                        }
                        return t.toString = function() {
                            return i.toString();
                        }, t;
                    }(function() {
                        clearTimeout(this.timer), this.timer = null;
                    })
                },
                beforeDestroy: function beforeDestroy() {
                    this.clearTimeout();
                }
            };
            t.default = r;
        }).call(this, e("543d")["default"]);
    },
    "9c95": function c95(i, t, e) {
        "use strict";
        e.r(t);
        var n = e("2420"), a = e("eb39");
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(i) {
            e.d(t, i, function() {
                return a[i];
            });
        }(u);
        e("03a9");
        var r = e("f0c5"), o = Object(r["a"])(a["default"], n["b"], n["c"], !1, null, "f147a924", null, !1, n["a"], void 0);
        t["default"] = o.exports;
    },
    bf37: function bf37(i, t, e) {},
    eb39: function eb39(i, t, e) {
        "use strict";
        e.r(t);
        var n = e("409d"), a = e.n(n);
        for (var u in n) [ "default" ].indexOf(u) < 0 && function(i) {
            e.d(t, i, function() {
                return n[i];
            });
        }(u);
        t["default"] = a.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "uni_modules/uview-ui/components/u-count-down/u-count-down-create-component", {
    "uni_modules/uview-ui/components/u-count-down/u-count-down-create-component": function uni_modulesUviewUiComponentsUCountDownUCountDownCreateComponent(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("9c95"));
    }
}, [ [ "uni_modules/uview-ui/components/u-count-down/u-count-down-create-component" ] ] ]);