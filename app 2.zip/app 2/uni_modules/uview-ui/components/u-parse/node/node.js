require("../../../../../@babel/runtime/helpers/Arrayincludes");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "uni_modules/uview-ui/components/u-parse/node/node" ], {
    "40f6": function f6(t, i, e) {
        "use strict";
        var n = e("63b1"), r = e.n(n);
        r.a;
    },
    "63b1": function b1(t, i, e) {},
    6686: function _(t, i, e) {
        "use strict";
        e.d(i, "b", function() {
            return n;
        }), e.d(i, "c", function() {
            return r;
        }), e.d(i, "a", function() {});
        var n = function n() {
            var t = this.$createElement;
            this._self._c;
        }, r = [];
    },
    7764: function _(t, i, e) {
        "use strict";
        e.r(i);
        var n = e("c864"), r = e.n(n);
        for (var o in n) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(i, t, function() {
                return n[t];
            });
        }(o);
        i["default"] = r.a;
    },
    b0fe: function b0fe(t, i, e) {
        "use strict";
        i["a"] = function(t) {
            t.options.wxsCallMethods || (t.options.wxsCallMethods = []);
        };
    },
    b794: function b794(t, i, e) {
        "use strict";
        e.r(i);
        var n = e("6686"), r = e("7764");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(i, t, function() {
                return r[t];
            });
        }(o);
        e("40f6");
        var s = e("f0c5"), a = e("b0fe"), u = Object(s["a"])(r["default"], n["b"], n["c"], !1, null, null, null, !1, n["a"], void 0);
        "function" === typeof a["a"] && Object(a["a"])(u), i["default"] = u.exports;
    },
    c864: function c864(t, i, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var n = {
                name: "node",
                options: {
                    virtualHost: !0
                },
                data: function data() {
                    return {
                        ctrl: {}
                    };
                },
                props: {
                    name: String,
                    attrs: {
                        type: Object,
                        default: function _default() {
                            return {};
                        }
                    },
                    childs: Array,
                    opts: Array
                },
                components: {
                    node: function node() {
                        Promise.resolve().then(function() {
                            return resolve(e("b794"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                mounted: function mounted() {
                    for (this.root = this.$parent; "mp-html" != this.root.$options.name; this.root = this.root.$parent) ;
                },
                beforeDestroy: function beforeDestroy() {},
                methods: {
                    toJSON: function toJSON() {},
                    play: function play(i) {
                        if (this.root.pauseVideo) {
                            for (var e = !1, n = i.target.id, r = this.root._videos.length; r--; ) this.root._videos[r].id == n ? e = !0 : this.root._videos[r].pause();
                            if (!e) {
                                var o = t.createVideoContext(n, this);
                                o.id = n, this.root._videos.push(o);
                            }
                        }
                    },
                    imgTap: function imgTap(i) {
                        var e = this.childs[i.currentTarget.dataset.i];
                        if (e.a) return this.linkTap(e.a);
                        e.attrs.ignore || (this.root.$emit("imgTap", e.attrs), this.root.previewImg && t.previewImage({
                            current: parseInt(e.attrs.i),
                            urls: this.root.imgList
                        }));
                    },
                    imgLongTap: function imgLongTap(t) {},
                    imgLoad: function imgLoad(t) {
                        var i = t.currentTarget.dataset.i;
                        this.childs[i].w ? (this.opts[1] && !this.ctrl[i] || -1 == this.ctrl[i]) && this.$set(this.ctrl, i, 1) : this.$set(this.ctrl, i, t.detail.width);
                    },
                    linkTap: function linkTap(i) {
                        var e = i.currentTarget ? this.childs[i.currentTarget.dataset.i].attrs : i, n = e.href;
                        this.root.$emit("linkTap", e), n && ("#" == n[0] ? this.root.navigateTo(n.substring(1)).catch(function() {}) : n.includes("://") ? this.root.copyLink && t.setClipboardData({
                            data: n,
                            success: function success() {
                                return t.showToast({
                                    title: "链接已复制"
                                });
                            }
                        }) : t.navigateTo({
                            url: n,
                            fail: function fail() {
                                t.switchTab({
                                    url: n,
                                    fail: function fail() {}
                                });
                            }
                        }));
                    },
                    mediaError: function mediaError(t) {
                        var i = t.currentTarget.dataset.i, e = this.childs[i];
                        if ("video" == e.name || "audio" == e.name) {
                            var n = (this.ctrl[i] || 0) + 1;
                            if (n > e.src.length && (n = 0), n < e.src.length) return this.$set(this.ctrl, i, n);
                        } else "img" == e.name && this.opts[2] && this.$set(this.ctrl, i, -1);
                        this.root && this.root.$emit("error", {
                            source: e.name,
                            attrs: e.attrs,
                            errMsg: t.detail.errMsg
                        });
                    }
                }
            };
            i.default = n;
        }).call(this, e("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "uni_modules/uview-ui/components/u-parse/node/node-create-component", {
    "uni_modules/uview-ui/components/u-parse/node/node-create-component": function uni_modulesUviewUiComponentsUParseNodeNodeCreateComponent(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("b794"));
    }
}, [ [ "uni_modules/uview-ui/components/u-parse/node/node-create-component" ] ] ]);