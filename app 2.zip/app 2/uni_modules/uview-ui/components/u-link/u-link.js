(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "uni_modules/uview-ui/components/u-link/u-link" ], {
    "19c6": function c6(t, n, i) {
        "use strict";
        i.d(n, "b", function() {
            return e;
        }), i.d(n, "c", function() {
            return u;
        }), i.d(n, "a", function() {});
        var e = function e() {
            var t = this.$createElement, n = (this._self._c, this.__get_style([ this.linkStyle, this.$u.addStyle(this.customStyle) ]));
            this.$mp.data = Object.assign({}, {
                $root: {
                    s0: n
                }
            });
        }, u = [];
    },
    3024: function _(t, n, i) {},
    "6bfe": function bfe(t, n, i) {
        "use strict";
        (function(t) {
            var e = i("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var u = e(i("2dc7")), c = {
                name: "u-link",
                mixins: [ t.$u.mpMixin, t.$u.mixin, u.default ],
                computed: {
                    linkStyle: function linkStyle() {
                        var n = {
                            color: this.color,
                            fontSize: t.$u.addUnit(this.fontSize),
                            lineHeight: t.$u.addUnit(t.$u.getPx(this.fontSize) + 2),
                            textDecoration: this.underLine ? "underline" : "none"
                        };
                        return n;
                    }
                },
                methods: {
                    openLink: function openLink() {
                        var n = this;
                        t.setClipboardData({
                            data: this.href,
                            success: function success() {
                                t.hideToast(), n.$nextTick(function() {
                                    t.$u.toast(n.mpTips);
                                });
                            }
                        }), this.$emit("click");
                    }
                }
            };
            n.default = c;
        }).call(this, i("543d")["default"]);
    },
    "745c": function c(t, n, i) {
        "use strict";
        i.r(n);
        var e = i("19c6"), u = i("bc55");
        for (var c in u) [ "default" ].indexOf(c) < 0 && function(t) {
            i.d(n, t, function() {
                return u[t];
            });
        }(c);
        i("76e0");
        var o = i("f0c5"), a = Object(o["a"])(u["default"], e["b"], e["c"], !1, null, "0f0cb6d2", null, !1, e["a"], void 0);
        n["default"] = a.exports;
    },
    "76e0": function e0(t, n, i) {
        "use strict";
        var e = i("3024"), u = i.n(e);
        u.a;
    },
    bc55: function bc55(t, n, i) {
        "use strict";
        i.r(n);
        var e = i("6bfe"), u = i.n(e);
        for (var c in e) [ "default" ].indexOf(c) < 0 && function(t) {
            i.d(n, t, function() {
                return e[t];
            });
        }(c);
        n["default"] = u.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "uni_modules/uview-ui/components/u-link/u-link-create-component", {
    "uni_modules/uview-ui/components/u-link/u-link-create-component": function uni_modulesUviewUiComponentsULinkULinkCreateComponent(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("745c"));
    }
}, [ [ "uni_modules/uview-ui/components/u-link/u-link-create-component" ] ] ]);