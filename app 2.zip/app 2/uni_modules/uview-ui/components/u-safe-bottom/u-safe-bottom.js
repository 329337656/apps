(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "uni_modules/uview-ui/components/u-safe-bottom/u-safe-bottom" ], {
    "03f5": function f5(t, e, n) {
        "use strict";
        (function(t) {
            var u = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = u(n("f8c5")), a = {
                name: "u-safe-bottom",
                mixins: [ t.$u.mpMixin, t.$u.mixin, i.default ],
                data: function data() {
                    return {
                        safeAreaBottomHeight: 0,
                        isNvue: !1
                    };
                },
                computed: {
                    style: function style() {
                        return t.$u.deepMerge({}, t.$u.addStyle(this.customStyle));
                    }
                },
                mounted: function mounted() {}
            };
            e.default = a;
        }).call(this, n("543d")["default"]);
    },
    2233: function _(t, e, n) {
        "use strict";
        var u = n("84df"), i = n.n(u);
        i.a;
    },
    "2ac5": function ac5(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("b179"), i = n("b464");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        n("2233");
        var o = n("f0c5"), f = Object(o["a"])(i["default"], u["b"], u["c"], !1, null, "01127184", null, !1, u["a"], void 0);
        e["default"] = f.exports;
    },
    "84df": function df(t, e, n) {},
    b179: function b179(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return u;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var u = function u() {
            var t = this.$createElement, e = (this._self._c, this.__get_style([ this.style ]));
            this.$mp.data = Object.assign({}, {
                $root: {
                    s0: e
                }
            });
        }, i = [];
    },
    b464: function b464(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("03f5"), i = n.n(u);
        for (var a in u) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(a);
        e["default"] = i.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "uni_modules/uview-ui/components/u-safe-bottom/u-safe-bottom-create-component", {
    "uni_modules/uview-ui/components/u-safe-bottom/u-safe-bottom-create-component": function uni_modulesUviewUiComponentsUSafeBottomUSafeBottomCreateComponent(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("2ac5"));
    }
}, [ [ "uni_modules/uview-ui/components/u-safe-bottom/u-safe-bottom-create-component" ] ] ]);