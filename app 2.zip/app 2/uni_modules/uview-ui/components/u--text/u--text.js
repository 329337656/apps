(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "uni_modules/uview-ui/components/u--text/u--text" ], {
    "2b57": function b57(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {});
        var u = function u() {
            var n = this.$createElement;
            this._self._c;
        }, i = [];
    },
    "451d": function d(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("df1b"), i = e.n(u);
        for (var o in u) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(o);
        t["default"] = i.a;
    },
    "66ca": function ca(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("2b57"), i = e("451d");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(o);
        var c = e("f0c5"), a = Object(c["a"])(i["default"], u["b"], u["c"], !1, null, null, null, !1, u["a"], void 0);
        t["default"] = a.exports;
    },
    df1b: function df1b(n, t, e) {
        "use strict";
        (function(n) {
            var u = e("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = u(e("2695")), o = {
                name: "u--text",
                mixins: [ n.$u.mpMixin, i.default, n.$u.mixin ],
                components: {
                    uvText: function uvText() {
                        Promise.all([ e.e("common/vendor"), e.e("uni_modules/uview-ui/components/u-text/u-text") ]).then(function() {
                            return resolve(e("0b77"));
                        }.bind(null, e)).catch(e.oe);
                    }
                }
            };
            t.default = o;
        }).call(this, e("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "uni_modules/uview-ui/components/u--text/u--text-create-component", {
    "uni_modules/uview-ui/components/u--text/u--text-create-component": function uni_modulesUviewUiComponentsUTextUTextCreateComponent(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("66ca"));
    }
}, [ [ "uni_modules/uview-ui/components/u--text/u--text-create-component" ] ] ]);