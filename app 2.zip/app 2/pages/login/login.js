(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "pages/login/login" ], {
    "0826": function _(e, t, n) {
        "use strict";
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n("2eee")), r = o(n("c973")), c = o(n("9523")), u = (n("45a6"), n("b5ec"), 
            n("26cb"));
            o(n("f15c"));
            function s(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function a(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? s(Object(n), !0).forEach(function(t) {
                        (0, c.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var l = {
                data: function data() {
                    return {
                        checked: !1,
                        loading: !1,
                        info: "",
                        model: {
                            account: "",
                            captcha: "",
                            password: ""
                        },
                        type: "pwd",
                        rules: {
                            phone: {
                                required: !0,
                                message: "请输入手机号",
                                trigger: [ "blur", "change" ]
                            },
                            captcha: {
                                required: !0,
                                message: "请输入短信验证码",
                                trigger: [ "blur", "change" ]
                            },
                            password: [ {
                                required: !0,
                                message: "请输入密码",
                                trigger: [ "blur", "change" ]
                            } ]
                        },
                        accept: [],
                        statusBarHeight: e.getSystemInfoSync()["statusBarHeight"],
                        loginTimer: null
                    };
                },
                onShow: function onShow() {
                    var t = this;
                    this.$http.get("/applyservice/system/sysDateMsg/getNowMsg").then(function(e) {
                        e.data.success && (t.info = e.data.result.indexContent);
                    }).catch(function(e) {
                        console.log(e);
                    }), this.accept = e.getStorageSync("ACCEPT");
                },
                methods: a(a({}, (0, u.mapActions)([ "login" ])), {}, {
                    goXy: function goXy() {
                        e.navigateTo({
                            url: "/apply/yhxy"
                        });
                    },
                    checkboxChange: function checkboxChange(e) {
                        this.checked = !this.checked;
                    },
                    sendCode: function sendCode() {
                        var t = {
                            phone: this.model.phone,
                            type: "login"
                        };
                        this.$http.post("/systemservice/sys/user/extend/sendSmsCode", t).then(function(t) {
                            200 === t.data.code ? e.showToast({
                                title: "短信已发送，请注意查收！",
                                duration: 1e3
                            }) : e.showToast({
                                title: "短信发送失败",
                                duration: 1e3
                            });
                        }).family(function() {});
                    },
                    forgetPwd: function forgetPwd() {
                        e.navigateTo({
                            url: "/apply/user/forgetPwd"
                        });
                    },
                    regist: function regist() {
                        e.navigateTo({
                            url: "/apply/user/register"
                        });
                    },
                    tabClick: function tabClick(e) {
                        this.type = e, this.$refs.form.clearValidate(), this.model = {};
                    },
                    acceptChange: function acceptChange(e) {
                        this.$store.commit("SET_ACCEPT", this.accept);
                    },
                    userAgreement: function userAgreement() {
                        e.navigateTo({
                            url: "/pages/login/userAgreement"
                        });
                    },
                    getLoginInfo: function getLoginInfo() {
                        return new Promise(function(t, n) {
                            try {
                                e.login({
                                    provider: "weixin",
                                    success: function success(e) {
                                        console.log("1111111111", e), "login:ok" === e.errMsg && e.code ? t(e.code) : t("");
                                    }
                                });
                            } catch (o) {
                                o = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(o);
                                console.log("获取用户登录信息报错:", o), n("");
                            }
                        });
                    },
                    onLogin: function onLogin() {
                        var t = this, n = this;
                        if (this.checked) {
                            if ("" !== this.model.phone) {
                                if ("pwd" === this.type) {
                                    if ("" === this.model.password) return void this.$tip.alert("请输入密码!");
                                } else if ("" === this.model.captcha) return void this.$tip.alert("请输入验证码!");
                                this.loginTimer && (clearTimeout(this.loginTimer), this.loginTimer = null), this.loginTimer = setTimeout(function() {
                                    n.loading && (n.loading = !1);
                                }, 3e4), this.$refs.form.validate().then(function() {
                                    var e = (0, r.default)(i.default.mark(function e(n) {
                                        var o, r;
                                        return i.default.wrap(function(e) {
                                            while (1) switch (e.prev = e.next) {
                                              case 0:
                                                return t.loading = !0, o = {}, o = "pwd" === t.type ? {
                                                    username: t.model.phone,
                                                    password: t.model.password,
                                                    type: "pwd"
                                                } : {
                                                    username: t.model.phone,
                                                    captcha: t.model.captcha,
                                                    type: "captcha"
                                                }, e.prev = 3, e.next = 6, t.getLoginInfo();

                                              case 6:
                                                r = e.sent, console.log("2222222222", r), r && (o.code = r), e.next = 14;
                                                break;

                                              case 11:
                                                e.prev = 11, e.t0 = e["catch"](3), console.log("异步获取登录code报错：", e.t0);

                                              case 14:
                                                o.agreementOn = "Y", t.login(o).then(function(e) {
                                                    if (e.data.success) {
                                                        t.$tip.success("登录成功!");
                                                        var n = t;
                                                        setTimeout(function() {
                                                            this.loading = !1, n.$Router.replaceAll({
                                                                name: "index"
                                                            });
                                                        }, 2e3);
                                                    } else t.loading = !1, t.$tip.alert(e.data.message);
                                                }).catch(function(e) {
                                                    t.loading = !1, t.$tip.alert(e);
                                                });

                                              case 16:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e, null, [ [ 3, 11 ] ]);
                                    }));
                                    return function(t) {
                                        return e.apply(this, arguments);
                                    };
                                }()).catch(function(n) {
                                    e.$u.toast(n), t.loading = !1;
                                });
                            } else this.$tip.alert("请输入手机号!");
                        } else e.showToast({
                            icon: "none",
                            title: "请勾选用户协议与隐私政策!",
                            duration: 1e3
                        });
                    },
                    saveClientId: function saveClientId() {
                        var e = this, t = plus.push.getClientInfo(), n = t.clientid;
                        this.$http.get("/sys/user/saveClientId", {
                            params: {
                                clientId: n
                            }
                        }).then(function(t) {
                            console.log("res::saveClientId>", t), e.$tip.success("登录成功!"), e.$Router.replaceAll({
                                name: "index"
                            });
                        });
                    }
                })
            };
            t.default = l;
        }).call(this, n("543d")["default"]);
    },
    "47aa": function aa(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            "u-Form": function uForm() {
                return Promise.all([ n.e("common/vendor"), n.e("uni_modules/uview-ui/components/u--form/u--form") ]).then(n.bind(null, "d2b4"));
            },
            uFormItem: function uFormItem() {
                return Promise.all([ n.e("common/vendor"), n.e("uni_modules/uview-ui/components/u-form-item/u-form-item") ]).then(n.bind(null, "3966"));
            },
            "u-Input": function uInput() {
                return Promise.all([ n.e("common/vendor"), n.e("uni_modules/uview-ui/components/u--input/u--input") ]).then(n.bind(null, "1888"));
            },
            uButton: function uButton() {
                return Promise.all([ n.e("common/vendor"), n.e("uni_modules/uview-ui/components/u-button/u-button") ]).then(n.bind(null, "af66"));
            },
            uCheckboxGroup: function uCheckboxGroup() {
                return Promise.all([ n.e("common/vendor"), n.e("uni_modules/uview-ui/components/u-checkbox-group/u-checkbox-group") ]).then(n.bind(null, "f2e3"));
            },
            uCheckbox: function uCheckbox() {
                return Promise.all([ n.e("common/vendor"), n.e("uni_modules/uview-ui/components/u-checkbox/u-checkbox") ]).then(n.bind(null, "461b"));
            }
        }, i = function i() {
            var e = this.$createElement;
            this._self._c;
        }, r = [];
    },
    "870f": function f(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("47aa"), i = n("a2b6");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        n("98f7");
        var c = n("f0c5"), u = Object(c["a"])(i["default"], o["b"], o["c"], !1, null, null, null, !1, o["a"], void 0);
        t["default"] = u.exports;
    },
    "98f7": function f7(e, t, n) {
        "use strict";
        var o = n("bec4"), i = n.n(o);
        i.a;
    },
    a2b6: function a2b6(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("0826"), i = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t["default"] = i.a;
    },
    bec4: function bec4(e, t, n) {},
    c011: function c011(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n("4ea4");
            n("3c1d");
            o(n("66fd"));
            var i = o(n("870f"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(i.default);
        }).call(this, n("bc2e")["default"], n("543d")["createPage"]);
    }
}, [ [ "c011", "common/runtime", "common/vendor" ] ] ]);