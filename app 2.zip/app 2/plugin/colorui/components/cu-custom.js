(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "plugin/colorui/components/cu-custom" ], {
    2577: function _(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("51d7"), u = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        e["default"] = u.a;
    },
    "51d7": function d7(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                data: function data() {
                    return {
                        StatusBar: this.StatusBar,
                        CustomBar: this.CustomBar
                    };
                },
                name: "cu-custom",
                computed: {
                    style: function style() {
                        var t = this.StatusBar, e = this.CustomBar, n = this.bgImage, a = "height:".concat(e, "px;padding-top:").concat(t, "px;");
                        return this.bgImage && (a = "".concat(a, "background-image:url(").concat(n, ");")), 
                        a;
                    }
                },
                props: {
                    bgColor: {
                        type: String,
                        default: ""
                    },
                    isBack: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    bgImage: {
                        type: String,
                        default: ""
                    },
                    type: {
                        type: String,
                        default: ""
                    }
                },
                methods: {
                    BackPage: function BackPage() {
                        console.log("点击了"), this.type ? "/pages/user/index" == this.type ? t.reLaunch({
                            url: "/pages/index/index?PageCur=mine"
                        }) : t.reLaunch({
                            url: this.type
                        }) : t.navigateBack({
                            delta: 1
                        });
                    }
                }
            };
            e.default = n;
        }).call(this, n("543d")["default"]);
    },
    "93de": function de(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("ed43"), u = n("2577");
        for (var i in u) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(i);
        var r = n("f0c5"), c = Object(r["a"])(u["default"], a["b"], a["c"], !1, null, null, null, !1, a["a"], void 0);
        e["default"] = c.exports;
    },
    ed43: function ed43(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return u;
        }), n.d(e, "a", function() {});
        var a = function a() {
            var t = this.$createElement;
            this._self._c;
        }, u = [];
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "plugin/colorui/components/cu-custom-create-component", {
    "plugin/colorui/components/cu-custom-create-component": function pluginColoruiComponentsCuCustomCreateComponent(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("93de"));
    }
}, [ [ "plugin/colorui/components/cu-custom-create-component" ] ] ]);